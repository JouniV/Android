//
// Source code for the AboutDescriptionActivity class
//
// 21.06.2011 Jouni Virtanen / LAMK / TIEIA08
//

package edu.lamk.tl;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class AboutDescriptionActivity extends Activity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate( Bundle savedInstanceState ) {
    	
        super.onCreate( savedInstanceState );
        
        // Set aboutdescription to screen
        setContentView(R.layout.aboutdescription);
    }

}

