//
// Source code for the RessuActivity class
//
// 21.06.2011 Jouni Virtanen / LAMK / TIEIA08
//

package edu.lamk.tl;

import java.util.Calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class RessuActivity extends Activity {
	
	private Calendar cal;
	private int dow;
	private int days_to_subtract;
	private String start_date;
	private String end_date;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate( Bundle savedInstanceState ) {
    	
        super.onCreate( savedInstanceState );
        
        // Set ressu layout to screen
        setContentView(R.layout.ressu);
        
        // Get the Calendar
        cal = Calendar.getInstance();
        
        // Get the day of the week
        dow = cal.get( Calendar.DAY_OF_WEEK );
        
        // Calculate how many days must be subtracted in order to get
        // the current week's Monday
        days_to_subtract = dow - 2;
        
        if ( days_to_subtract > 0 )
        {
        	// The current day is between Tuesday and Saturday
        	cal.add( Calendar.DATE, -days_to_subtract );
        }
        else if ( days_to_subtract < 0 )
        {
        	// The current day is Sunday
        	cal.add( Calendar.DATE, -6 );
        }
        
        // Build the start_date
        start_date = cal.get( Calendar.YEAR ) + "-" + ( cal.get( Calendar.MONTH ) + 1 ) + "-" + cal.get( Calendar.DATE );
        
        // Add six days to Monday in order to get the current
        // weeks's Sunday
        cal.add( Calendar.DATE, 6 );
        
        // Build the end_date
        end_date = cal.get( Calendar.YEAR ) + "-" + ( cal.get( Calendar.MONTH ) + 1 ) + "-" + cal.get( Calendar.DATE );
        
        // Get the current week's timetable from Reppu to screen
        WebView webview = (WebView) findViewById( R.id.ressu_webView );
        webview.loadUrl( "http://ressu.lpt.fi/oklukuj/lukuj2.aspx?pvm1=" + start_date + "&pvm2=" + end_date + "&tunnus=07TIEIA08&tyyppi=Ryhma&tpiste=07TL&tulostus=true&oletus=e" );
    }
}

