//
// Android Tehtava 1 
//
// 21.06.2011 Jouni Virtanen / LAMK / TIEIA08
//

package edu.lamk.tl;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.maps.*;


public class Tehtava_1 extends MapActivity implements SensorEventListener 
{
	
	private LocationManager mlocManager;
	private LocationListener mlocListener;	
	private Double lat;
	private Double lng;
	private MapView mapView;
	private GeoPoint point;
	private List<Overlay> mapOverlays;
	private Drawable drawable;
	private MapController mc;
	private boolean animate = true;
	private boolean track = false;
	private boolean compass_1 = true;
	private boolean compass_2 = true;	
	private boolean previousTrack = false;
	private ArrayList<GeoPoint> geopoints = new ArrayList<GeoPoint>();
	private Display display;
	private Float azimuth = null;
	private Float pitch = null;
	private Float roll = null;
	private SensorManager sensorManager;
	private Sensor accelerometer;
	private Sensor magnetometer;
	private float[] gravity;
	private float[] geomagnetic;	
	private MyLocationOverlay myLocationOverlay;
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate( Bundle savedInstanceState ) {
        
    	super.onCreate( savedInstanceState );
    	
    	// Set main layout to screen
        setContentView( R.layout.main );
        
        // Set GPS location listener
        mlocManager = (LocationManager) getSystemService( Context.LOCATION_SERVICE ); 
        mlocListener = new MyLocationListener(); 


        // Create Ressu button and its listener
        Button ressuButton = (Button) findViewById( R.id.ressu_button );
        
        ressuButton.setOnClickListener( new OnClickListener() {
			
			public void onClick( View v ) {
				// TODO Auto-generated method stub
				Log.d( "DemoActivity", "onclick called!" );
				LaunchRessu();
			}
		}
        		
        );
        

        // Create About button and its listener
        Button aboutButton = (Button) findViewById( R.id.about_button );
        
        aboutButton.setOnClickListener( new OnClickListener() {
			
			public void onClick( View v ) {
				// TODO Auto-generated method stub
				Log.d( "AboutDescriptionActivity", "onclick called!" );
				LaunchAboutDescription();
			}
		}
        		
        );
        
        
        // Create Animation button and its listener
        Button animationButton = (Button) findViewById( R.id.animation_button );
        
        animationButton.setOnClickListener( new OnClickListener() {
			
			public void onClick( View v ) {
				// TODO Auto-generated method stub
				Log.d( "Animation button", "onclick called!" );
				animate = !( animate );
			}
		}
        		
        );        
        
        
        // Create Track button and its listener
        Button trackButton = (Button) findViewById( R.id.track_button );
        
        trackButton.setOnClickListener( new OnClickListener() {
			
			public void onClick( View v ) {
				// TODO Auto-generated method stub
				Log.d( "Track button", "onclick called!" );
				track = !( track );
			}
		}
        		
        );
        

        // Create compass 1 button and its listener
        Button compass1Button = (Button) findViewById( R.id.compass_1_button );
        
        compass1Button.setOnClickListener( new OnClickListener() {
			
			public void onClick( View v ) {
				// TODO Auto-generated method stub
				Log.d( "Compass1 button", "onclick called!" );
				compass_1 = !( compass_1 );
			}
		}
        		
        );        
        
        // Create compass 2 button and its listener
        Button compass2Button = (Button) findViewById( R.id.compass_2_button );
        
        compass2Button.setOnClickListener( new OnClickListener() {
			
			public void onClick( View v ) {
				// TODO Auto-generated method stub
				Log.d( "Compass2 button", "onclick called!" );
				compass_2 = !( compass_2 );
			}
		}
        		
        );
        
        
        // Add zoom controls to mapView
        mapView = (MapView) findViewById( R.id.google_mapView );
        mapView.setBuiltInZoomControls( true );
        
        // Get mapView's overlays and green_dot marker
    	mapOverlays = mapView.getOverlays();
    	drawable = this.getResources().getDrawable( R.drawable.green_dot );
    	
		// Register the sensor listeners
		sensorManager = (SensorManager) getSystemService( SENSOR_SERVICE );
		accelerometer = sensorManager.getDefaultSensor( Sensor.TYPE_ACCELEROMETER );
		magnetometer = sensorManager.getDefaultSensor( Sensor.TYPE_MAGNETIC_FIELD );
    	
    	// Get mapView's controller
    	mc = mapView.getController();
    	
    	// Get default display 
    	display = ( (WindowManager) getSystemService( WINDOW_SERVICE ) ).getDefaultDisplay();
    	
    	// Create MyLocationOverlay, this is needed in order to show
    	// Google maps compass on the mapView
    	myLocationOverlay = new MyLocationOverlay( this, mapView );
    	myLocationOverlay.enableCompass();    	
    }
    
	protected void onResume() {
		
		super.onResume();
		
		// Enable GPS location updates
        mlocManager.requestLocationUpdates( LocationManager.GPS_PROVIDER, 0, 0, mlocListener );
        
        // Enable sensor manager updates
		sensorManager.registerListener( this, accelerometer, SensorManager.SENSOR_DELAY_UI );
		sensorManager.registerListener( this, magnetometer, SensorManager.SENSOR_DELAY_UI );
	}
	
	protected void onPause() {
		
		super.onPause();
		
		// Disable GPS location updates 
		mlocManager.removeUpdates( mlocListener );
		
		// Disable sensor manager updates		
		sensorManager.unregisterListener( this );
	}    
        
    
	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	
	// Launch AboutDescriptionActivity
	public void LaunchAboutDescription()
    {
    	Intent intent = new Intent( this, AboutDescriptionActivity.class );
    	startActivity( intent );
    }
	
	// Launch RessuActivity
	public void LaunchRessu()
    {
    	Intent intent = new Intent( this, RessuActivity.class );
    	startActivity( intent );
    }

	public void onAccuracyChanged( Sensor sensor, int accuracy ) {
		
	}
	
	
	// Get sensor manager azimuth, pitch and roll
	public void onSensorChanged(SensorEvent event) {
		
		if ( event.sensor.getType() == Sensor.TYPE_ACCELEROMETER )
			gravity = event.values;
		
		if ( event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD )
			geomagnetic = event.values;
		
		if ( gravity != null && geomagnetic != null) {
			
			float R_local[] = new float[ 9 ];
			float I[] = new float[ 9 ];
			
			boolean success = SensorManager.getRotationMatrix( R_local, I, gravity, geomagnetic );
			
			if ( success ) {
				float orientation[] = new float[3];
				SensorManager.getOrientation( R_local, orientation );
				
				// orientation contains: azimuth, pitch and roll
				azimuth = orientation[ 0 ]; 
				pitch = orientation[ 1 ];
				roll = orientation[ 2 ];
			}
			
		}
	}
	
	/* Class My Location Listener */ 
	public class MyLocationListener implements LocationListener 
	{ 

		// Framework calls this method on GPS location change
		public void onLocationChanged( Location loc ) 
		{ 

			String Text = "My current location is: " +" Latitude = " + loc.getLatitude() +" Longitude = " + loc.getLongitude(); 
			Log.d( "GPS location", Text );
	
			// Set GPS location to screen
			TextView tv_1 = (TextView) findViewById( R.id.lat_textView );
	        tv_1.setText( loc.getLatitude() + "" );
	        
	        TextView tv_2 = (TextView) findViewById( R.id.long_textView );
	        tv_2.setText( loc.getLongitude() + "" );
	        
			// Set pitch and roll to screen
			TextView tv_3 = (TextView) findViewById( R.id.pitch_textView );
	        tv_3.setText( pitch + "" );
	        
			TextView tv_4 = (TextView) findViewById( R.id.roll_textView );
	        tv_4.setText( roll + "" );	        
	        
	        // Add start of GPS tracking flag ( point == null )
	        // if the tracking was just started
	        if ( track == true && previousTrack == false )
			{
				point = null;
				geopoints.add( point );
			}
	        
	        // Convert GPS location to GeoPoint
	        lat = loc.getLatitude() * 1E6;
			lng = loc.getLongitude() * 1E6;
			point = new GeoPoint( lat.intValue(), lng.intValue() );

			// Add GeoPoint to mapOverlay
			Tehtava_1_ItemizedOverlay itemizedoverlay = new Tehtava_1_ItemizedOverlay( drawable );			
			OverlayItem overlayitem = new OverlayItem( point, "", "" );
			itemizedoverlay.addOverlay( overlayitem, geopoints, track, compass_1, display, azimuth );
			mapOverlays.clear();	
			mapOverlays.add( itemizedoverlay );
			
			// Add Google maps compass to mapOverlay if compass 2 is on   
			if ( compass_2 == true )
			{
				mapOverlays.add( myLocationOverlay );			
			}
			
			// Animate to GPS location if animating is on
			if ( animate == true )
			{
				mc.animateTo( point );
			}
			
			// Store GeoPoint to memory if tracking is on
			if ( track == true )
			{
				geopoints.add( point );
			}
			
			// Store the current status of tracking
			previousTrack = track;
		}  


		public void onProviderDisabled( String provider ) 
		{ 

		} 
	 

		public void onProviderEnabled( String provider ) 
		{ 

		} 


		public void onStatusChanged( String provider, int status, Bundle extras ) 
		{ 


		} 

	}/* End of Class MyLocationListener */
}