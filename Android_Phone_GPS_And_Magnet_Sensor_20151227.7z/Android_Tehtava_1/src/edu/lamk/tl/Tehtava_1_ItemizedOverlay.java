//
// Source code for the Tehtava_1_ItemizedOverlay class
//
// 21.06.2011 Jouni Virtanen / LAMK / TIEIA08
//

package edu.lamk.tl;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.view.Display;
import android.view.Surface;


import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;

public class Tehtava_1_ItemizedOverlay extends  ItemizedOverlay {
	
	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
	private Context mContext;
	private Point point = new Point();
	private Point previousPoint = null;
	private ArrayList<GeoPoint> geopoints = null;
	private Paint paint = new Paint();
	private boolean track = false;
	private int width;
	private int height;
	private int centerx;
	private int centery;
	private boolean compass_1 = false;
	private Display display;	
	private Float azimuth;
	private final int COMPASS_RADIUS = 150;

	public Tehtava_1_ItemizedOverlay( Drawable defaultMarker ) {
		
		// TODO Auto-generated constructor stub
		super( boundCenterBottom( defaultMarker ) );
	}

	public Tehtava_1_ItemizedOverlay( Drawable defaultMarker, Context context ) {
		
		super( defaultMarker );
		this.mContext = context;
	}	
	
	// Add new overlay to ArrayList
	// Parameters:
	//	- New overlay
	//	- Tracked GeoPoints
	//	- Boolean type variable tracking on / off
	public void addOverlay( OverlayItem overlay, ArrayList<GeoPoint> geopoints, boolean track, boolean compass_1, Display display, Float azimuth ) {
		
		mOverlays.add( overlay );

		this.geopoints = geopoints;
		this.track = track;
		this.compass_1 = compass_1;
		this.display = display;
		this.azimuth = azimuth;
		
		populate();
	}	

	@Override
	protected OverlayItem createItem( int i ) {
		// TODO Auto-generated method stub
		return mOverlays.get( i );
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return mOverlays.size();
	}


	
	@Override
	public void draw( Canvas canvas, MapView mapView, boolean shadow ) {
		
		super.draw( canvas, mapView, shadow );

		// If tracking is on
		if ( track == true && shadow == false )		
		{
			int i;
			
			// Set Paint object's attributes
			paint.setStyle( Style.STROKE );
			paint.setColor( Color.parseColor ( "#88ff0000" ) );
			paint.setAntiAlias( true );
			paint.setStrokeWidth( 4 );
			
			// Get mapView's projection
			Projection projection = mapView.getProjection();

			// Draw a line between tracked GPS locations
			for ( i = 0 ; i < geopoints.size(); i++ )
			{
				// Search the start of tracking flag
				if ( geopoints.get( i ) == null )
				{
					// Skip the start of tracking GPS location, it is just a flag
					if ( ++i < geopoints.size() )
					{
						// Allocate space for the previous GPS location
						if ( previousPoint == null )
						{
							previousPoint = new Point();
						}
						// Store the previous GPS location
						projection.toPixels( geopoints.get( i ), previousPoint );
					}
				}
				else
				{
					// Convert GeoPoint to pixels
					projection.toPixels( geopoints.get( i ), point );
			
					// Draw a line between GeoPoints
					canvas.drawLine( previousPoint.x, previousPoint.y, point.x, point.y, paint );
					previousPoint.x = point.x;
					previousPoint.y = point.y;
				}
			}
		}
		
		// Draw compass 1 If compass1 is on
		if ( compass_1 == true && shadow == false )
		{
			// Save canvas before rotating
			canvas.save();

			// Get mapView width and height
			width = mapView.getWidth();
			height = mapView.getHeight();

			// Calculate mapView center point
			centerx = width/2;
			centery = height/2;
		
			// Set Paint object's attributes
			paint.setColor(0xff0000ff);
			paint.setStyle(Style.STROKE);
			paint.setStrokeWidth(2);
			paint.setAntiAlias(true);
			paint.setTextSize(34);
		
			// Rotate canvas towards to North
			if ( azimuth != null )
				canvas.rotate( -azimuth * 360 / ( 2*3.14159f ), centerx, centery );
		
			// Draw compass x and y axis
			canvas.drawLine(centerx, centery - COMPASS_RADIUS, centerx, centery + COMPASS_RADIUS, paint);
			canvas.drawLine(centerx - COMPASS_RADIUS, centery, centerx + COMPASS_RADIUS, centery, paint);
		
			// Draw compass North, East, South and West symbols according to surface rotation
			if ( display.getOrientation() == Surface.ROTATION_0 )
			{
				canvas.drawText("W", centerx - COMPASS_RADIUS, centery, paint);			
				canvas.drawText("E", centerx + COMPASS_RADIUS, centery, paint);
				canvas.drawText("N", centerx, centery - COMPASS_RADIUS, paint);
				canvas.drawText("S", centerx, centery + COMPASS_RADIUS, paint);
			}
			else if ( display.getOrientation() == Surface.ROTATION_90 )
			{
				canvas.drawText("N", centerx - COMPASS_RADIUS, centery, paint);			
				canvas.drawText("S", centerx + COMPASS_RADIUS, centery, paint);
				canvas.drawText("E", centerx, centery - COMPASS_RADIUS, paint);
				canvas.drawText("W", centerx, centery + COMPASS_RADIUS, paint);				
			}
			else if ( display.getOrientation() == Surface.ROTATION_270 )
			{
				canvas.drawText("S", centerx - COMPASS_RADIUS, centery, paint);			
				canvas.drawText("N", centerx + COMPASS_RADIUS, centery, paint);
				canvas.drawText("W", centerx, centery - COMPASS_RADIUS, paint);
				canvas.drawText("E", centerx, centery + COMPASS_RADIUS, paint);				
			}
		
			// Restore canvas
			canvas.restore();
		}
	}
}
